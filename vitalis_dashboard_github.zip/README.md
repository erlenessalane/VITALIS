# Vitalis Dashboard Financeiro

Site estático pronto para GitHub Pages.

## Como publicar
1. Criar repositório no GitHub.
2. Enviar `index.html` e `dados-financeiros.json`.
3. Ativar GitHub Pages em Settings > Pages.

## Senha inicial
`Vitalis@2026`

## Atualização diária
Atualize o ficheiro `dados-financeiros.json` no GitHub. O dashboard lê esse ficheiro sempre que abre.

> Atenção: senha em site estático é apenas barreira simples. Para dados financeiros reais, usar Microsoft/Power BI, Cloudflare Access ou backend com autenticação.
